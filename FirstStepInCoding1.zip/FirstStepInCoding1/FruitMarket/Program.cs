﻿using System;
using System.Runtime.InteropServices;
using System.Transactions;

namespace FruitMarket
{
    class Program
    {
        static void Main(string[] args)
        {

            //1.Цена на ягодите в лева – реално число в интервала[0.00 … 10000.00]
            double priceForStrawberries = double.Parse(Console.ReadLine());

            //2.Количество на бананите в килограми – реално число в интервала[0.00 … 1 0000.00]
            double bananasInKg = double.Parse(Console.ReadLine());

            //3.Количество на портокалите в килограми – реално число в интервала[0.00 … 10000.00]
            double orangesInKg = double.Parse(Console.ReadLine());

            //4.Количество на малините в килограми – реално число в интервала[0.00 … 10000.00]
            double raspberriesInKg = double.Parse(Console.ReadLine());

            //5.Количество на ягодите в килограми – реално число в интервала[0.00 … 10000.00]
            double strawberriesInKg = double.Parse(Console.ReadLine());

            //Изчисления

            //цената на малините е на половина по - ниска от тази на ягодите;
            double priceForRaspberries = priceForStrawberries / 2;

            //цената на портокалите е с 40 % по - ниска от цената на малините;
            double priceForOranges = priceForRaspberries - (0.40 * priceForRaspberries);

            //цената на бананите е с 80 % по - ниска от цената на малините.
            double priceForBananas = priceForRaspberries - (0.80 * priceForRaspberries);

            double sumForRaspberries = priceForRaspberries * raspberriesInKg;
            double sumForOranges = priceForOranges * orangesInKg;
            double sumForBananas = priceForBananas * bananasInKg;
            double sumForStrawberries = priceForStrawberries * strawberriesInKg;
            double totalSum = sumForRaspberries + sumForOranges + sumForBananas + sumForStrawberries;

            Console.WriteLine($"{totalSum:f2}");
           

        }

        
    }
}
