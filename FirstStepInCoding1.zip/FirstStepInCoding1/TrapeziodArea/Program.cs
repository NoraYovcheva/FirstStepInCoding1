﻿using System;
using System.Dynamic;

namespace TrapeziodArea
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            
            var h = double.Parse(Console.ReadLine());

            var area = (a * h / 2);
            Console.WriteLine($"{area:f2}");

            
        }
    }
}
