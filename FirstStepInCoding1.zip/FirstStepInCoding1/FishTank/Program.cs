﻿using System;

namespace FishTank
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Дължина в см – цяло число в интервала[10 … 500]
            int longInSm = int.Parse(Console.ReadLine());
            //2.Широчина в см – цяло число в интервала[10 … 300]
            int widthInSm = int.Parse(Console.ReadLine());
            //3.Височина в см – цяло число в интервала[10… 200]
            int hightInsm = int.Parse(Console.ReadLine());
            //4.Процент – реално число в интервала[0.000 … 100.000]
            double percent = double.Parse(Console.ReadLine());

            //Изчисления за обема на аквариума
            //обем на аквариум = 85 * 75 * 47 = 299625 см 3
            double volume = longInSm * widthInSm * hightInsm;
            //общо литри, които ще събере: 299625 * 0.001 = 299.625 литра
            double totalInLiter = volume * 0.001;
            //процент: 17 * 0.01 = 0.17
            double newPercent = percent * 0.01;
            //литрите, които реално ще трябват : 299.625 * (1 - 0.17) = 248.68875 литра
            Console.WriteLine(totalInLiter * (1 - newPercent));
        }
    }
}
