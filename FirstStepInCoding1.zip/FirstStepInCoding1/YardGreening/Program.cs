﻿using System;
using System.Runtime.InteropServices.ComTypes;

namespace YardGreening
{
    class Program
    {
        static void Main(string[] args)
        {
            double square = double.Parse(Console.ReadLine());
            double expencive = square * 7.61;
            double discount = expencive * 0.18;
            double total = expencive - discount;
            Console.WriteLine($"The final price is: {total:f2} lv.");
            Console.WriteLine($"The discount is: {discount:f2} lv.");
        }
    }
}
