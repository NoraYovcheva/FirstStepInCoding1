﻿using System;
using System.Dynamic;

namespace GreetingByName
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Броят на кучетата – цяло число в интервала[0… 100]
            //2.Броят на останалите животни - цяло число в интервала[0… 100]
            string nameOfTheArchitect = Console.ReadLine();
            int countOfProject = int.Parse(Console.ReadLine());
            
            int timeNeedForMultipleProjects = countOfProject * 3;
            
            Console.WriteLine($"The architect {nameOfTheArchitect} will need {timeNeedForMultipleProjects} hours to complete {countOfProject} project/s.");
        }
    }
}
