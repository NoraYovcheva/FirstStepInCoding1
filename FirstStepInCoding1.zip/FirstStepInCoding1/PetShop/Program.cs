﻿using System;

namespace PetShop
{
    class Program
    {
        static void Main(string[] args)
        {
            int countOfDogs = int.Parse(Console.ReadLine());
            int countOfTheOtherAnimals = int.Parse(Console.ReadLine());
            double dogFood = 2.50;
            double otherFoodAnimals = 4.00;
            double sum = (countOfDogs * dogFood) + (countOfTheOtherAnimals * otherFoodAnimals);
            Console.WriteLine($"{sum} lv.");
        }
    }
}
