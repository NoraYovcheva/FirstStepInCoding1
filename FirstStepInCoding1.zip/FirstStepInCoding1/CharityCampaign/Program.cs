﻿using System;
using System.Transactions;

namespace CharityCampaign
{
    class Program
    {
        static void Main(string[] args)
        {
            //Константи цени
            
            //Торта - 45 лв.
            const double priceForCake = 45;
            //Гофрета - 5.80 лв.
            const double priceForWaffle = 5.80;
            //Палачинка – 3.20 лв.
            const double priceForPancake = 3.20;
            //Прочитане на данните
           
            //1.Броят на дните, в които тече кампанията – цяло число в интервала[0 … 365]
            int campaignDays = int.Parse(Console.ReadLine());
            //2.Броят на сладкарите – цяло число в интервала[0 … 1000]
            int numberOfCookers = int.Parse(Console.ReadLine());
            //3.Броят на тортите – цяло число в интервала[0… 2000]
            int numberOfCakes= int.Parse(Console.ReadLine());
            //4.Броят на гофретите – цяло число в интервала[0 … 2000]
            int numberOfWaffels = int.Parse(Console.ReadLine());
            //5.Броят на палачинките – цяло число в интервала[0 … 2000]
            int NumberOfPancakes = int.Parse(Console.ReadLine());
           
            // Изчисления 
            double cakeTotalPrice = numberOfCakes * priceForCake;
            double wafflesTotalPrice = numberOfWaffels * priceForWaffle;
            double pancalesTotalPrice = NumberOfPancakes * priceForPancake;
            double totalPricePerDay = (cakeTotalPrice + wafflesTotalPrice + pancalesTotalPrice) * numberOfCookers;
            double campaignDaysTotal = totalPricePerDay * campaignDays;
            double amountAfterCoveringTheCosts = campaignDaysTotal - (campaignDaysTotal /8 );

            //Принтиране на конзолата
            Console.WriteLine(amountAfterCoveringTheCosts);


        }
    }
}
