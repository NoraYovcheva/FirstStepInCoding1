﻿using System;
using System.Transactions;

namespace DepositCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            double deposit = double.Parse(Console.ReadLine());
            int months = int.Parse(Console.ReadLine());
            double annualPersantAge = Double.Parse(Console.ReadLine());
            double divident = (deposit * (annualPersantAge / 100)) / 12;
            double sum = deposit + (months * divident);
            Console.WriteLine(sum);
        }
    }
}
